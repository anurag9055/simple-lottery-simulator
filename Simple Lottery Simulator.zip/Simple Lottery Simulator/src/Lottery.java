import java.util.Arrays;
import java.util.Scanner;

public class Lottery{

    public static void main(String[]args){
        Scanner entry =new Scanner(System.in);

        int ticketAmnt;

        do {
            System.out.print("How many tickets will you be generating (1 to 100)? -->");
            ticketAmnt = entry.nextInt();
        }while (ticketAmnt<1|| ticketAmnt>100);
        int[] randomNumbers;
        int lottery[][]=new int[ticketAmnt][];

        int ticketcount=0;
        boolean unique=false;
        while(ticketcount<ticketAmnt){
            randomNumbers=new int [6];
            int havesix=0;
            while(havesix<6){
                int randomNum=(int)(Math.random()*49+1);
                unique=true;
                for(int n:randomNumbers){
                    if (n==randomNum){
                        unique=false;
                        break;
                    }
                }
                if(unique){
                    randomNumbers[havesix]=randomNum;
                    havesix++;
                }
            }
            Arrays.sort(randomNumbers);

            unique=true;
            for(int[]ary:lottery) {
                //Is the set unique?
                if(Arrays.toString(ary).equals(Arrays.toString(randomNumbers))){
                    //Nope...break out create another new set of ticket number
                    unique=false;
                    break;
                }
            }
            if(unique){
                lottery[ticketcount]=randomNumbers;
                ticketcount++;
            }
        }
        //print the lottery tickets to count window;
        for(int i=0;i<lottery.length;i++){
            System.out.println("Ticket #"+(i+1)+";-->"
             +Arrays.toString(lottery[i]).replaceAll("[\\[\\]]",""));
        }

    }
}